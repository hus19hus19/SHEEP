const CACHE_NAME = 'sheep-farm-cache-v1';
// قائمة الملفات التي يجب تخزينها (App Shell)
const urlsToCache = [
  './', // يشير إلى index.html
  './index.html',
  './manifest.json',
  // إذا أنشأت مجلد icons، قم بإضافة المسارات التالية
  // '/icons/icon-192x192.png', 
  // '/icons/icon-512x512.png',
  
  // موارد الطرف الثالث (يجب إضافتها لتعمل دون اتصال)
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css',
  'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'
];

// 1. تثبيت العامل الخدمي وتخزين الموارد
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache and caching app shell');
        return cache.addAll(urlsToCache);
      })
      .catch(err => {
        console.error('Failed to cache resources:', err);
      })
  );
});

// 2. تفعيل العامل الخدمي وتنظيف الكاش القديم
self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// 3. استراتيجية "Cache First" لجلب الموارد
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // إذا كان المورد موجودًا في الكاش، قم بإرجاعه فوراً
        if (response) {
          return response;
        }
        // وإلا، قم بالذهاب إلى الشبكة لجلب المورد
        return fetch(event.request);
      })
  );
});
